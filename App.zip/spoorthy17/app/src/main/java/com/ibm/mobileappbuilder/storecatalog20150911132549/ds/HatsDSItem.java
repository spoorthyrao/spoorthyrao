
package com.ibm.mobileappbuilder.storecatalog20150911132549.ds;
import android.graphics.Bitmap;
import android.net.Uri;

import ibmmobileappbuilder.mvp.model.IdentifiableBean;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;

public class HatsDSItem implements Parcelable, IdentifiableBean {

    @SerializedName("name") public String name;
    @SerializedName("desc") public String desc;
    @SerializedName("picture") public String picture;
    @SerializedName("cost") public String cost;
    @SerializedName("id") public String id;
    @SerializedName("pictureUri") public transient Uri pictureUri;

    @Override
    public String getIdentifiableId() {
      return id;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(name);
        dest.writeString(desc);
        dest.writeString(picture);
        dest.writeString(cost);
        dest.writeString(id);
    }

    public static final Creator<HatsDSItem> CREATOR = new Creator<HatsDSItem>() {
        @Override
        public HatsDSItem createFromParcel(Parcel in) {
            HatsDSItem item = new HatsDSItem();

            item.name = in.readString();
            item.desc = in.readString();
            item.picture = in.readString();
            item.cost = in.readString();
            item.id = in.readString();
            return item;
        }

        @Override
        public HatsDSItem[] newArray(int size) {
            return new HatsDSItem[size];
        }
    };

}


