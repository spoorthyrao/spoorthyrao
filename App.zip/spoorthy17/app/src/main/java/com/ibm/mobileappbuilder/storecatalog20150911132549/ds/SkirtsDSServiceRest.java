
package com.ibm.mobileappbuilder.storecatalog20150911132549.ds;
import java.util.List;
import retrofit.Callback;
import retrofit.http.GET;
import retrofit.http.Query;
import retrofit.http.POST;
import retrofit.http.Body;
import retrofit.http.DELETE;
import retrofit.http.Path;
import retrofit.http.PUT;
import retrofit.mime.TypedByteArray;
import retrofit.http.Part;
import retrofit.http.Multipart;

public interface SkirtsDSServiceRest{

	@GET("/app/57ef51ce9d17e00300d4cc5e/r/skirtsDS")
	void querySkirtsDSItem(
		@Query("skip") String skip,
		@Query("limit") String limit,
		@Query("conditions") String conditions,
		@Query("sort") String sort,
		@Query("select") String select,
		@Query("populate") String populate,
		Callback<List<SkirtsDSItem>> cb);

	@GET("/app/57ef51ce9d17e00300d4cc5e/r/skirtsDS/{id}")
	void getSkirtsDSItemById(@Path("id") String id, Callback<SkirtsDSItem> cb);

	@DELETE("/app/57ef51ce9d17e00300d4cc5e/r/skirtsDS/{id}")
  void deleteSkirtsDSItemById(@Path("id") String id, Callback<SkirtsDSItem> cb);

  @POST("/app/57ef51ce9d17e00300d4cc5e/r/skirtsDS/deleteByIds")
  void deleteByIds(@Body List<String> ids, Callback<List<SkirtsDSItem>> cb);

  @POST("/app/57ef51ce9d17e00300d4cc5e/r/skirtsDS")
  void createSkirtsDSItem(@Body SkirtsDSItem item, Callback<SkirtsDSItem> cb);

  @PUT("/app/57ef51ce9d17e00300d4cc5e/r/skirtsDS/{id}")
  void updateSkirtsDSItem(@Path("id") String id, @Body SkirtsDSItem item, Callback<SkirtsDSItem> cb);

  @GET("/app/57ef51ce9d17e00300d4cc5e/r/skirtsDS")
  void distinct(
        @Query("distinct") String colName,
        @Query("conditions") String conditions,
        Callback<List<String>> cb);
    
    @Multipart
    @POST("/app/57ef51ce9d17e00300d4cc5e/r/skirtsDS")
    void createSkirtsDSItem(
        @Part("data") SkirtsDSItem item,
        @Part("picture") TypedByteArray picture,
        Callback<SkirtsDSItem> cb);
    
    @Multipart
    @PUT("/app/57ef51ce9d17e00300d4cc5e/r/skirtsDS/{id}")
    void updateSkirtsDSItem(
        @Path("id") String id,
        @Part("data") SkirtsDSItem item,
        @Part("picture") TypedByteArray picture,
        Callback<SkirtsDSItem> cb);
}

