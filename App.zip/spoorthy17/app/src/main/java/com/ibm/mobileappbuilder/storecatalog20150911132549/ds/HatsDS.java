

package com.ibm.mobileappbuilder.storecatalog20150911132549.ds;

import android.content.Context;

import java.net.URL;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;

import ibmmobileappbuilder.ds.SearchOptions;
import ibmmobileappbuilder.ds.restds.AppNowDatasource;
import ibmmobileappbuilder.util.StringUtils;
import ibmmobileappbuilder.ds.restds.TypedByteArrayUtils;

import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;

/**
 * "HatsDS" data source. (e37eb8dc-6eb2-4635-8592-5eb9696050e3)
 */
public class HatsDS extends AppNowDatasource<HatsDSItem>{

    // default page size
    private static final int PAGE_SIZE = 20;

    private HatsDSService service;

    public static HatsDS getInstance(SearchOptions searchOptions){
        return new HatsDS(searchOptions);
    }

    private HatsDS(SearchOptions searchOptions) {
        super(searchOptions);
        this.service = HatsDSService.getInstance();
    }

    @Override
    public void getItem(String id, final Listener<HatsDSItem> listener) {
        if ("0".equals(id)) {
                        getItems(new Listener<List<HatsDSItem>>() {
                @Override
                public void onSuccess(List<HatsDSItem> items) {
                    if(items != null && items.size() > 0) {
                        listener.onSuccess(items.get(0));
                    } else {
                        listener.onSuccess(new HatsDSItem());
                    }
                }

                @Override
                public void onFailure(Exception e) {
                    listener.onFailure(e);
                }
            });
        } else {
                      service.getServiceProxy().getHatsDSItemById(id, new Callback<HatsDSItem>() {
                @Override
                public void success(HatsDSItem result, Response response) {
                                        listener.onSuccess(result);
                }

                @Override
                public void failure(RetrofitError error) {
                                        listener.onFailure(error);
                }
            });
        }
    }

    @Override
    public void getItems(final Listener<List<HatsDSItem>> listener) {
        getItems(0, listener);
    }

    @Override
    public void getItems(int pagenum, final Listener<List<HatsDSItem>> listener) {
        String conditions = getConditions(searchOptions, getSearchableFields());
        int skipNum = pagenum * PAGE_SIZE;
        String skip = skipNum == 0 ? null : String.valueOf(skipNum);
        String limit = PAGE_SIZE == 0 ? null: String.valueOf(PAGE_SIZE);
        String sort = getSort(searchOptions);
                service.getServiceProxy().queryHatsDSItem(
                skip,
                limit,
                conditions,
                sort,
                null,
                null,
                new Callback<List<HatsDSItem>>() {
            @Override
            public void success(List<HatsDSItem> result, Response response) {
                                listener.onSuccess(result);
            }

            @Override
            public void failure(RetrofitError error) {
                                listener.onFailure(error);
            }
        });
    }

    private String[] getSearchableFields() {
        return new String[]{"name", "desc", "cost"};
    }

    // Pagination

    @Override
    public int getPageSize(){
        return PAGE_SIZE;
    }

    @Override
    public void getUniqueValuesFor(String searchStr, final Listener<List<String>> listener) {
        String conditions = getConditions(searchOptions, getSearchableFields());
                service.getServiceProxy().distinct(searchStr, conditions, new Callback<List<String>>() {
             @Override
             public void success(List<String> result, Response response) {
                                  result.removeAll(Collections.<String>singleton(null));
                 listener.onSuccess(result);
             }

             @Override
             public void failure(RetrofitError error) {
                                  listener.onFailure(error);
             }
        });
    }

    @Override
    public URL getImageUrl(String path) {
        return service.getImageUrl(path);
    }

    @Override
    public void create(HatsDSItem item, Listener<HatsDSItem> listener) {
                    
        if(item.pictureUri != null){
            service.getServiceProxy().createHatsDSItem(item,
                TypedByteArrayUtils.fromUri(item.pictureUri),
                callbackFor(listener));
        }
        else
            service.getServiceProxy().createHatsDSItem(item, callbackFor(listener));
        
    }

    private Callback<HatsDSItem> callbackFor(final Listener<HatsDSItem> listener) {
      return new Callback<HatsDSItem>() {
          @Override
          public void success(HatsDSItem item, Response response) {
                            listener.onSuccess(item);
          }

          @Override
          public void failure(RetrofitError error) {
                            listener.onFailure(error);
          }
      };
    }

    @Override
    public void updateItem(HatsDSItem item, Listener<HatsDSItem> listener) {
                    
        if(item.pictureUri != null){
            service.getServiceProxy().updateHatsDSItem(item.getIdentifiableId(),
                item,
                TypedByteArrayUtils.fromUri(item.pictureUri),
                callbackFor(listener));
        }
        else
            service.getServiceProxy().updateHatsDSItem(item.getIdentifiableId(), item, callbackFor(listener));
        
    }

    @Override
    public void deleteItem(HatsDSItem item, final Listener<HatsDSItem> listener) {
                service.getServiceProxy().deleteHatsDSItemById(item.getIdentifiableId(), new Callback<HatsDSItem>() {
            @Override
            public void success(HatsDSItem result, Response response) {
                                listener.onSuccess(result);
            }

            @Override
            public void failure(RetrofitError error) {
                                listener.onFailure(error);
            }
        });
    }

    @Override
    public void deleteItems(List<HatsDSItem> items, final Listener<HatsDSItem> listener) {
                service.getServiceProxy().deleteByIds(collectIds(items), new Callback<List<HatsDSItem>>() {
            @Override
            public void success(List<HatsDSItem> item, Response response) {
                                listener.onSuccess(null);
            }

            @Override
            public void failure(RetrofitError error) {
                                listener.onFailure(error);
            }
        });
    }

    protected List<String> collectIds(List<HatsDSItem> items){
        List<String> ids = new ArrayList<>();
        for(HatsDSItem item: items){
            ids.add(item.getIdentifiableId());
        }
        return ids;
    }

}

