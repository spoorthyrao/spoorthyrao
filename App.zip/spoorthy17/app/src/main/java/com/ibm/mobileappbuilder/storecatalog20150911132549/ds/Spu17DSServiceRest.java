
package com.ibm.mobileappbuilder.storecatalog20150911132549.ds;
import java.util.List;
import retrofit.Callback;
import retrofit.http.GET;
import retrofit.http.Query;
import retrofit.http.POST;
import retrofit.http.Body;
import retrofit.http.DELETE;
import retrofit.http.Path;
import retrofit.http.PUT;
import retrofit.mime.TypedByteArray;
import retrofit.http.Part;
import retrofit.http.Multipart;

public interface Spu17DSServiceRest{

	@GET("/app/57ef51ce9d17e00300d4cc5e/r/spu17DS")
	void querySpu17DSItem(
		@Query("skip") String skip,
		@Query("limit") String limit,
		@Query("conditions") String conditions,
		@Query("sort") String sort,
		@Query("select") String select,
		@Query("populate") String populate,
		Callback<List<Spu17DSItem>> cb);

	@GET("/app/57ef51ce9d17e00300d4cc5e/r/spu17DS/{id}")
	void getSpu17DSItemById(@Path("id") String id, Callback<Spu17DSItem> cb);

	@DELETE("/app/57ef51ce9d17e00300d4cc5e/r/spu17DS/{id}")
  void deleteSpu17DSItemById(@Path("id") String id, Callback<Spu17DSItem> cb);

  @POST("/app/57ef51ce9d17e00300d4cc5e/r/spu17DS/deleteByIds")
  void deleteByIds(@Body List<String> ids, Callback<List<Spu17DSItem>> cb);

  @POST("/app/57ef51ce9d17e00300d4cc5e/r/spu17DS")
  void createSpu17DSItem(@Body Spu17DSItem item, Callback<Spu17DSItem> cb);

  @PUT("/app/57ef51ce9d17e00300d4cc5e/r/spu17DS/{id}")
  void updateSpu17DSItem(@Path("id") String id, @Body Spu17DSItem item, Callback<Spu17DSItem> cb);

  @GET("/app/57ef51ce9d17e00300d4cc5e/r/spu17DS")
  void distinct(
        @Query("distinct") String colName,
        @Query("conditions") String conditions,
        Callback<List<String>> cb);
    
    @Multipart
    @POST("/app/57ef51ce9d17e00300d4cc5e/r/spu17DS")
    void createSpu17DSItem(
        @Part("data") Spu17DSItem item,
        @Part("picture") TypedByteArray picture,
        Callback<Spu17DSItem> cb);
    
    @Multipart
    @PUT("/app/57ef51ce9d17e00300d4cc5e/r/spu17DS/{id}")
    void updateSpu17DSItem(
        @Path("id") String id,
        @Part("data") Spu17DSItem item,
        @Part("picture") TypedByteArray picture,
        Callback<Spu17DSItem> cb);
}

